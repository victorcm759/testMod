
rootProject.name = "ForgeGradle-1.2"

include("separated")
