package net.minecraftforge.gradle.json.version;

public enum Action {
    ALLOW,
    DISALLOW;
}
