package net.minecraftforge.gradle.json.curse;

public class CurseDep extends CurseReply {
    public String name, slug;
}
