package net.minecraftforge.gradle.json;

import java.util.List;
import java.util.Map;

public class GLConstantGroup {
    public Map<String, List<String>> functions;
    public Map<String, Map<String, String>> constants;
}
