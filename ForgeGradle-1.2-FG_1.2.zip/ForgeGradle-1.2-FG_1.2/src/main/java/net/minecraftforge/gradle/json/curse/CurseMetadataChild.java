package net.minecraftforge.gradle.json.curse;

public class CurseMetadataChild {
    public String changelog, releaseType, displayName;
    public int parentFileID;
}
