package net.minecraftforge.gradle.json.curse;

public class CurseVersion extends CurseDep {
    public int gameDependencyID = 0;
}
