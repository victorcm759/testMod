package net.minecraftforge.gradle.json.curse;

import java.util.HashSet;
import java.util.Set;

public class CurseRelations {

    /**
     * A set of related projects
     */
    public final Set<CurseProjectDep> projects = new HashSet<>();
}
