package net.minecraftforge.gradle.json.curse;

public class CurseError {
    public int errorCode;
    public String errorMessage;
}
