package net.minecraftforge.gradle.json.curse;

public class CurseReply {
    public int id;
}
