ForgeGradle
===========

Join Chat [![Discord](https://img.shields.io/discord/834256470580396043)](https://discord.gg/yzEdnuJMXv)

Minecraft mod development framework used by Forge and FML for the gradle build system

this repository is only for ForgeGradle 1.2, ForgeGradle for minecraft 1.7.2, 1.7.10, and 1.8.

[Here](https://github.com/anatawa12/ForgeGradle-2.3) is repository for ForgeGradle 2.3. If you're modding for 1.12.x, use it.

This project is a fork of [ForgeGradle branch 'FG_1.2'](https://github.com/MinecraftForge/ForgeGradle/tree/FG_1.2).

[Example project found here](https://github.com/anatawa12/ForgeGradle-example)

[Documentation found here](http://forgegradle.readthedocs.org/)

## How to replace ForgeGradle 1.2. with anatawa12's fork

See [How to replace ForgeGradle 1.2. with anatawa12's fork in example project](https://github.com/anatawa12/ForgeGradle-example#how-to-replace-forgegradle-12-with-anatawa12s-fork)
